"""Run every case in data/eval_cases.json and print a pass/fail table.
Works with or without a Gemini key. Usage:  python run_eval.py
"""
import json
from pathlib import Path

from app import pipeline

cases = json.loads((Path(__file__).parent / "data" / "eval_cases.json").read_text(encoding="utf-8"))
passed = 0
print(f"{'#':>2}  {'result':<6} {'expected':<13} {'got':<13} question")
for i, c in enumerate(cases, 1):
    r = pipeline.answer(c["q"])
    ok = r["type"] == c["type"]
    if ok and c["type"] == "answer":
        ok = any(c["expect"] == cit["section"] for cit in r["citations"])
    if ok and c["type"] in ("not_found", "out_of_scope"):
        ok = r["citations"] == []          # nothing to cite -> no citation card
    passed += ok
    print(f"{i:>2}  {'PASS' if ok else 'FAIL':<6} {c['type']:<13} {r['type']:<13} {c['q'][:70]}")
print(f"\n{passed}/{len(cases)} passed")
