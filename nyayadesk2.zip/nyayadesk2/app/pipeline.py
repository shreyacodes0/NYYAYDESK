"""The whole chatbot in one place: question in -> checked answer out.

Steps
  1. safety.check        refuse injections, personal disputes, other areas of law
  2. retrieval.search    find matching passages in the knowledge base
  3. llm.ask_gemini      (optional) plain-language explanation from those passages only
  4. verify              drop the model's answer if it names a section we did not retrieve
  5. build response      citations always come from the knowledge base, never from the model
"""
import re

from app import llm, retrieval, safety

ACT_SECTION_COUNT = 107  # the Consumer Protection Act, 2019 has sections 1-107

# General complaint route, each step tied to knowledge-base passages
ROADMAP = [
    {
        "step": "If you bought online, write to the e-commerce entity's Grievance Officer. "
                "It must acknowledge the complaint within 48 hours and resolve it within one month.",
        "authority": "Grievance Officer of the e-commerce entity",
        "source_ids": ["ecom-rules-2020-rule4-duties"],
    },
    {
        "step": "Raise an informal complaint with the National Consumer Helpline: call 1915 "
                "or register on consumerhelpline.gov.in.",
        "authority": "National Consumer Helpline",
        "source_ids": ["nch-redressal-1915"],
    },
    {
        "step": "If it is still unresolved, file a complaint within two years of the cause of action. "
                "The Commission depends on the value paid: District up to Rs 50 lakh, State above Rs 50 lakh "
                "up to Rs 2 crore, National above Rs 2 crore. Complaints can be filed online on e-Daakhil.",
        "authority": "District / State / National Consumer Disputes Redressal Commission",
        "source_ids": ["cpa2019-sec69-limitation", "cpa2019-sec34-district-comm",
                       "cdrc-jurisdiction-limits-2021", "edaakhil-process-overview"],
    },
]


def _citation(p: dict) -> dict:
    return {
        "id": p["id"],
        "document": p["document_title"],
        "section": p["section_number"],
        "authority": p["issuing_authority"],
        "text": p["content"],
        "url": p["official_url"],
        "needs_verification": p.get("needs_verification", False),
    }


ONLINE_HINT = re.compile(r"\b(online|website|web\s*site|app|e-?commerce|platform|marketplace|delivery|delivered|cart|checkout|booking)\b", re.I)


def _roadmap(question: str = "") -> list[dict]:
    """Complaint route. The Grievance Officer step only applies to online purchases."""
    online = bool(ONLINE_HINT.search(question))
    steps = []
    for i, r in enumerate(ROADMAP):
        if i == 0 and not online:
            continue
        labels = [f"{retrieval.KB_BY_ID[i]['document_title']}, {retrieval.KB_BY_ID[i]['section_number']}"
                  for i in r["source_ids"]]
        steps.append({"step": r["step"], "authority": r["authority"], "sources": labels})
    return steps


def _response(kind, answer, citations=None, procedure=None, mode="rules"):
    return {
        "type": kind,  # answer | refusal | not_found | out_of_scope
        "answer": answer,
        "citations": [_citation(p) for p in (citations or [])],
        "procedure": procedure or [],
        "disclaimer": safety.DISCLAIMER,
        "mode": mode,
    }


def _model_answer_is_valid(data, passages) -> bool:
    """Reject answers that cite sections/rules we did not retrieve, or use unknown ids."""
    if not isinstance(data, dict) or not data.get("answer") or data["answer"].strip() == "NOT_COVERED":
        return False
    allowed_ids = {p["id"] for p in passages}
    if not set(data.get("used_ids", [])) <= allowed_ids or not data.get("used_ids"):
        return False
    allowed_numbers = set()
    for p in passages:
        allowed_numbers |= set(re.findall(r"\d+", p["section_number"]))
    for number in re.findall(r"\b(?:section|rule|sections|rules)\s+(\d+)", data["answer"].lower()):
        if number not in allowed_numbers:
            return False
    return True


def answer(question: str) -> dict:
    question = question.strip()

    # 1. safety
    verdict = safety.check(question)
    if verdict["kind"] == "injection":
        return _response("refusal",
                         "I can't follow instructions that change how I work. I can answer questions about "
                         "the Consumer Protection Act, 2019 and the Consumer Protection (E-Commerce) Rules, 2020.")
    if verdict["kind"] == "out_of_scope":
        return _response("out_of_scope",
                         f"That question is about {verdict['area']}, which is outside the Consumer Protection Act, "
                         f"2019 and its rules, the only documents I cover. Please contact {verdict['where']}.")

    # 2. retrieval (a named section is looked up directly)
    wanted = retrieval.find_section_reference(question)
    passages = retrieval.search(question)
    if wanted is not None:
        exact = [p for p in retrieval.KB
                 if p["section_number"] == f"Section {wanted}" or p["section_number"].startswith(f"Section {wanted}(")]
        if not exact:
            if wanted > ACT_SECTION_COUNT:
                msg = (f"There is no Section {wanted} in the Consumer Protection Act, 2019. "
                       f"The Act has sections 1 to {ACT_SECTION_COUNT}.")
            else:
                msg = f"Section {wanted} is not one of the passages I have indexed, so I can't quote it."
            return _response("not_found", msg)
        passages = exact + [p for p in passages if p['id'] not in {e['id'] for e in exact}]
        passages = passages[:3]

    # second opinion: the model checks for personal disputes the patterns missed
    if verdict["kind"] == "ok" and llm.classify_question(question) == "PERSONAL":
        verdict = {"kind": "personal_dispute"}

    if verdict["kind"] == "personal_dispute":
        base = ("I can't analyse your specific dispute or tell you whether you would win. "
                "Here is what the law says in general on this topic, and the usual route for complaints. "
                "For advice on your own situation, please consult an advocate.")
        return _response("refusal", base, citations=passages, procedure=_roadmap(question))

    if len(retrieval.tokenize(question)) < 2:
        return _response("not_found", "Could you add a little more detail? For example, say what kind of "
                                      "purchase or problem you are asking about.")
    if not passages:
        return _response("not_found", "I couldn't find a passage about that in the documents I cover "
                                      "(the Consumer Protection Act, 2019 and the E-Commerce Rules, 2020), "
                                      "so I won't guess.")

    # 3-4. optional model explanation, verified
    data = llm.ask_gemini(question, passages)
    if data is not None and _model_answer_is_valid(data, passages):
        used = [p for p in passages if p["id"] in data["used_ids"]]
        return _response("answer", data["answer"].strip(), citations=used, procedure=_roadmap(question), mode="gemini")

    # 5. fallback: quote the best passage directly
    top = passages[0]
    text = f"{top['document_title']} — {top['content']}"
    return _response("answer", text, citations=passages, procedure=_roadmap(question), mode="extractive")
