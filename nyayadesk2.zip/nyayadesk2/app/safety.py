"""Safety checks that run BEFORE any answer is written.

Plain pattern matching on purpose: it is predictable, fast, and easy to test.
The model never sees a question that fails one of these checks.

Order matters: injection -> personal dispute -> out-of-scope law.
"""
import re

DISCLAIMER = (
    "NyayaDesk provides general legal information, not legal advice. "
    "It does not analyse individual ongoing cases or disputes. "
    "For your own situation, consult an advocate or call the National Consumer Helpline at 1915."
)

INJECTION = [
    r"ignore\s+(all\s+|any\s+|your\s+)?(previous|prior|above|earlier)\s+(instructions|rules)",
    r"(reveal|show|print|output|repeat)\s+(me\s+)?(the\s+|your\s+)?(secret\s+)?(system\s+prompt|instructions)",
    r"you\s+are\s+now\s+\w+",
    r"(developer|jailbreak|dan)\s+mode",
    r"pretend\s+(to\s+be|you\s+are)",
    r"override\s+(all\s+)?(safety|rules)",
    r"delete\s+(the\s+)?(database|index|files|data)",
]

# Asking for an outcome, strategy or court paperwork for the user's own matter
PERSONAL_OUTCOME = [
    r"\b(will|can|could)\s+i\s+(win|sue|beat)\b",
    r"\bchances?\s+of\s+(winning|success)\b",
    r"\b(percentage|probability|odds)\b.*\b(win|winning|success)\b",
    r"\bshould\s+i\s+(sue|file|go\s+to\s+court)\b",
    r"\bdo\s+i\s+have\s+a\s+(strong\s+|good\s+)?case\b",
    r"\b(my|our)\s+(case|dispute|hearing|lawyer|advocate)\b",
    r"\bcase\s+(no|number)\b|\bcc\s*/\s*\d+",
    r"\bhearing\s+(is\s+)?(tomorrow|today|next)\b",
    r"\b(strategy|guarantee)\b.*\b(judge|court|win|award)\b",
    r"\bdraft\b.*\b(affidavit|petition|plaint|pleading|legal\s+notice|complaint)\b",
]

# "I bought X and the seller did Y" = describing a personal dispute
PERSONAL_FACTS = re.compile(
    r"\b((i|we)\s+(bought|purchased|ordered|paid|booked|received)|"
    r"my\s+(seller|dealer|landlord|shop|shopkeeper|builder|bank|insurer|airline|order|laptop|phone|car|product|refund|complaint))\b"
)
DISPUTE_WORDS = re.compile(
    r"\b(refus\w*|den(y|ied|ies)|reject\w*|cheat\w*|lying|lied|broke|broken|defective|faulty|"
    r"not\s+(giving|refunding|replacing|repairing|responding)|overcharg\w*|fraud\w*|scam\w*|"
    r"damaged|never\s+(delivered|arrived)|harass\w*)\b"
)

# Other areas of law, with where to send the person
OUT_OF_SCOPE = [
    (r"\b(divorce|alimony|child\s+custody|hindu\s+marriage|maintenance\s+under)\b",
     "family and matrimonial law", "a Family Court or the District Legal Services Authority"),
    (r"\b(anticipatory\s+bail|bail\s+application|crpc|code\s+of\s+criminal\s+procedure|bns|ipc|fir)\b",
     "criminal law", "the local police station or the District Legal Services Authority"),
    (r"\b(income\s+tax|itr|gst|section\s+234f|tax\s+return)\b",
     "tax law", "the Income Tax Department (incometax.gov.in) or a Chartered Accountant"),
    (r"\b(property\s+partition|ancestral\s+(land|property)|mutation\s+of\s+land|khata)\b",
     "property and revenue law", "the Sub-Registrar / Revenue office or a property advocate"),
]


def check(question: str) -> dict:
    """Return {'kind': 'ok' | 'injection' | 'personal_dispute' | 'out_of_scope', ...}."""
    q = question.lower().strip()

    for pat in INJECTION:
        if re.search(pat, q):
            return {"kind": "injection"}

    for pat in PERSONAL_OUTCOME:
        if re.search(pat, q):
            return {"kind": "personal_dispute"}
    if PERSONAL_FACTS.search(q) and DISPUTE_WORDS.search(q):
        return {"kind": "personal_dispute"}

    for pat, area, where in OUT_OF_SCOPE:
        if re.search(pat, q):
            return {"kind": "out_of_scope", "area": area, "where": where}

    return {"kind": "ok"}
