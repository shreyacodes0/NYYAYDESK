"""Retrieval: find the passages in the knowledge base that match a question.

Plain keyword scoring (no vector database) so every step can be explained:
  1. split the question into stemmed words and drop filler words
  2. score each passage: words found in its keywords/section count more than
     words found only in its body; rare words count more than common ones
  3. keep passages above a minimum score, so unrelated questions return nothing
"""
import json
import math
import re
from pathlib import Path

KB_PATH = Path(__file__).resolve().parent.parent / "data" / "knowledge_base.json"

STOPWORDS = set("""a an the of to in on for and or is are was were be been it its this that these those
i me my we our you your can could should would will do does did how what when where which who whom why
if as at by from with about into than then there their they them not no any all under act india indian
please tell explain consumer protection law legal rule rules regulation regulations specific provision""".split())

# everyday words -> words used in the law
SYNONYMS = {
    "refund": ["return", "cancel", "cancellation"],
    "money": ["consideration", "refund"],
    "fake": ["false", "misleading"],
    "ad": ["advertisement", "advertising"],
    "ads": ["advertisement"],
    "lawyer": ["advocate"],
    "online": ["ecommerce", "electronic"],
    "court": ["commission"],
    "forum": ["commission"],
    "time": ["period", "limitation"],
    "deadline": ["limitation", "period"],
    "late": ["delay", "limitation"],
    "warranty": ["deficiency", "defect"],
    "faulty": ["defect", "defective"],
    "broken": ["defect", "defective"],
    "complain": ["complaint"],
    "helpline": ["nch", "national"],
    "number": ["toll", "1915"],
    "limit": ["pecuniary", "jurisdiction"],
    "fee": ["charges", "cancellation"],
    "fees": ["charges", "cancellation"],
}


def stem(word: str) -> str:
    """Very small stemmer: cancelled/cancels -> cancel, charges/charge -> charg."""
    for suffix in ("ing", "ed", "es", "s", "ly"):
        if word.endswith(suffix) and len(word) - len(suffix) >= 3:
            word = word[: -len(suffix)]
            break
    if word.endswith("e") and len(word) >= 5:
        word = word[:-1]
    if word.endswith("ll") and len(word) >= 6:
        word = word[:-1]
    return word


def tokenize(text: str) -> list[str]:
    words = re.findall(r"[a-z0-9]+", text.lower())
    return [stem(w) for w in words if w not in STOPWORDS and len(w) > 1]


def load_kb() -> list[dict]:
    with open(KB_PATH, encoding="utf-8") as f:
        return json.load(f)


KB = load_kb()
KB_BY_ID = {p["id"]: p for p in KB}

# field weights: where a matching word was found
W_KEYWORD, W_SECTION, W_BODY = 3.0, 2.5, 1.0

_fields = []
for _p in KB:
    _fields.append({
        "keyword": {t for k in _p["keywords"] for t in tokenize(k)},
        "section": set(tokenize(_p["section_number"] + " " + _p["document_title"])),
        "body": set(tokenize(_p["content"])),
    })

# inverse document frequency: words in few passages are more informative
_df = {}
for _f in _fields:
    for _t in _f["keyword"] | _f["section"] | _f["body"]:
        _df[_t] = _df.get(_t, 0) + 1


def idf(token: str) -> float:
    return math.log((len(KB) + 1) / (_df.get(token, 0) + 0.5))


def search(query: str, top_k: int = 3, min_score: float = 0.30) -> list[dict]:
    """Return up to top_k passages as dicts with an added 'score' (0..1)."""
    q_tokens = set(tokenize(query))
    expanded = {}
    for t in q_tokens:
        expanded[t] = 1.0
        for syn in SYNONYMS.get(t, []):
            expanded.setdefault(stem(syn), 0.6)
    if not expanded:
        return []

    # words that appear nowhere in the knowledge base (e.g. "site") should not lower the score
    known = [t for t in q_tokens if t in _df]
    # if most of the question is about things the knowledge base never mentions, don't guess
    if not known or len(known) / len(q_tokens) < 0.4:
        return []
    best_possible = sum(idf(t) * W_KEYWORD for t in known) or 1.0
    scored = []
    for passage, f in zip(KB, _fields):
        total = 0.0
        matched_words = set()   # distinct words from the user's question that were found
        strong = False          # a match in keywords/section, not just in the body text
        for token, weight in expanded.items():
            if token in f["section"]:
                field_w = W_SECTION
            elif token in f["keyword"]:
                field_w = W_KEYWORD
            elif token in f["body"]:
                field_w = W_BODY
            else:
                continue
            if token in q_tokens:
                matched_words.add(token)
            strong = strong or field_w >= W_SECTION
            total += idf(token) * weight * field_w
        score = min(total / best_possible, 1.0)
        # one weak body-text match is not enough evidence to answer
        if score >= min_score and (len(matched_words) >= 2 or (strong and len(known) <= 2)):
            scored.append({**passage, "score": round(score, 3)})

    scored.sort(key=lambda p: p["score"], reverse=True)
    if not scored:
        return []
    cutoff = scored[0]["score"] * 0.6  # drop weak passages next to a strong one
    return [p for p in scored if p["score"] >= cutoff][:top_k]


def find_section_reference(query: str):
    """If the user names 'Section N' return N as an int, else None."""
    m = re.search(r"\bsection\s+(\d+)", query.lower())
    return int(m.group(1)) if m else None
