# NyayaDesk – Consumer Law Information Chatbot

A chatbot that explains rights and procedures from **one documented rule set**: the
Consumer Protection Act, 2019 and the Consumer Protection (E-Commerce) Rules, 2020 (India).

It meets the assignment rules:

| Requirement | How it is done |
|---|---|
| Cite the exact clause | Every answer shows the passage(s) used, with document, section and authority. Quotes come from `data/knowledge_base.json`, never from the model. |
| Correct procedure and authority | Every answer and every refusal shows the complaint route (Grievance Officer → National Consumer Helpline → Consumer Commission) with the authority for each step. |
| States "information, not legal advice" | Shown in the page header and under every reply. |
| Refuses individual cases/disputes | `app/safety.py` runs before anything else. Questions like "will I win?" or "my seller refused…" get a refusal plus general information only. |

## How it works

```
question
  -> safety.py      refuse prompt-injection / personal dispute / other areas of law (patterns)
  -> llm.py         second opinion: Gemini labels the question GENERAL or PERSONAL (only if a key is set)
  -> retrieval.py   keyword search over the knowledge base (returns nothing if the evidence is weak)
  -> llm.py         optional: Gemini explains, using ONLY the retrieved passages
  -> pipeline.py    verify the model's answer; if it names a section we did not retrieve, throw it away
  -> response       citations are copied from the knowledge base
```

Without a Gemini key the bot still works: it quotes the best passage directly ("extractive" mode).
With a key, Gemini only rewrites the passages in plain language. There is no web search.

## Run it

```bash
python -m venv venv
venv\Scripts\activate          # Windows   (Mac/Linux: source venv/bin/activate)
pip install -r requirements.txt
copy .env.example .env         # then paste your Gemini key (optional)
uvicorn app.main:app --reload
```
Open http://127.0.0.1:8000

## Test it

```bash
pytest -q          # 10 unit tests, no API key needed
python run_eval.py # 24 questions: normal, personal-case, injection, other law, unknown section
```

## Files

- `app/safety.py` – the refusal rules
- `app/retrieval.py` – search over the knowledge base
- `app/llm.py` – the Gemini call and its system prompt
- `app/pipeline.py` – ties the steps together and verifies the answer
- `app/main.py` – the web API
- `static/index.html` – the chat page
- `data/knowledge_base.json` – the 16 passages (the only source of answers)
- `data/eval_cases.json` – test questions

## Limitations (say these in your presentation)

- Only 16 passages are indexed. Questions about other parts of the Act get "not found".
- Passages marked `needs_verification` in the knowledge base are summaries whose wording and
  rule numbers must be compared with the official text before you rely on them.
- Safety uses patterns plus a model second opinion (only with a Gemini key), so a cleverly worded personal-dispute question can still slip through.
- Memory: each question is answered on its own; the bot does not remember earlier messages.
- Retrieval is keyword-based; unusual wording can miss the right passage.

## AI use declaration

This project was built with AI assistance (Google AI Studio and Claude). Add your own name,
the date and what you changed or checked.
